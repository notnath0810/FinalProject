<?php
date_default_timezone_set('Asia/Manila');

// Database configuration — update host/user/pass to match your XAMPP setup
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'contact_tracing_db');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    // Never expose raw errors to the browser
    error_log('Database connection failed: ' . $conn->connect_error);
    die('A database error occurred. Please contact the administrator.');
}

$conn->set_charset('utf8mb4');

/**
 * Format a DATETIME string to Philippine format: "Month DD, YYYY HH:MM AM/PM"
 */
function formatPHTime(?string $datetime): string {
    if (empty($datetime)) {
        return '—';
    }
    $ts = strtotime($datetime);
    return date('F d, Y h:i A', $ts);
}

/**
 * Sanitize output to prevent XSS
 */
function e(string $val): string {
    return htmlspecialchars($val, ENT_QUOTES, 'UTF-8');
}
